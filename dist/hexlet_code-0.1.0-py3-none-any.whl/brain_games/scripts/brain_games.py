#!/usr/bin/env python

def main():

    print('Welcome to the Brain Games!')

main()

from cli import welcome_user
from cli import name

welcome_user(name)

