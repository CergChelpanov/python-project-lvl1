#!/usr/bin/env python
text = 'Welcome to the Brain Games!'
def main(text):
    print(format(text))

main(text)

