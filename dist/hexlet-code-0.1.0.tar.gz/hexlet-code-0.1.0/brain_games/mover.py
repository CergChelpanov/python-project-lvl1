# file <mover.py>

# BEGIN

import prompt

correct_answer = 2
answer = 1
wrong_answer = 2
name = ''
the_task = ''


def question(the_task, answer, correct_answer):
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print('Hello, {}!'.format(name))
    i = 3
    while i > 0:
        if __name__ == '__main__':
            the_task = '1+1'
            correct_answer = 2
        else:
            coplete_the_game()
        i = i -1
        print('Question:', the_task)
        answer = prompt.string('Your answer: ')
        if str(answer) != str(correct_answer):
            wrong_answer(answer, correct_answer)
            quit()
        else:
            true_answer()
    print(f'Congratulations, {name}!')


def wrong_answer(wrong_answer, correct_answer):
    print("'{}' is wrong answer ;(. Correct answer was'{}'.".format(wrong_answer, correct_answer))


def true_answer():
    print('Correct!')


def main():
    question('1+1',2,2)

if __name__ == '__main__':
    main()

# END

