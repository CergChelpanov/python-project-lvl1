#!/usr/bin/env python

import prompt


def main():

    print('Welcome to the Brain Games!')

main()

name = prompt.string('May I have your name? ')

print('Hello,', name)

